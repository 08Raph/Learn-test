# Testing Learn 3.1

## Running the tests
Needs Node.js with Playwright and Chromium (`npm i playwright && npx playwright install chromium`) and
Python 3 for the local web server. From the site folder:

```
sh tests/run-all.sh
```

| File | What it does |
|---|---|
| `tests/validate-content.js` | Loads every course file through the real parser and grader. Checks lesson counts against the catalogue, every knowledge check, every examination, and **runs every assignment's solution (must pass) and starter code (must fail)**. Also checks interview exercises and department data. |
| `tests/e2e-core.js` | 57 browser checks under the `/Learn/` path: gating, a whole course through the interface, examination fail and retake, project, persistence, professor, input safety, videos, offline, three screen sizes. |
| `tests/e2e-campus.js` | 78 checks: stage final fail and pass, certificate download, electives, eight departments, career centre, CV builder safety, interview exercises, study tools, weekly challenge, all eight professor modes, runner-failure handling, old-save compatibility, service-worker update, cloud-sync merge, layout and labels. |

The browser tests block Firebase, the code-runner services, Google Fonts and YouTube, so they are
repeatable and never touch a live service.

## Results for this release (all executed on 11 November 2026)

| Suite | Result |
|---|---|
| Content validator: 13 files, 55 courses (52 + 3 electives), 267 lessons, 917 knowledge-check and exam questions, 80 graded code tasks, 6 interview exercises | **0 problems** |
| e2e-core | **57 passed, 0 failed** |
| e2e-campus | **78 passed, 0 failed** |
| Existing-app regressions (Terminal Basics lessons, extra questions, C / C++ / C# / SQL lesson solutions, mobile layout) | **passed** |
| Scan of 13 routes for visible escaping artefacts after the `esc()` fix | **none found** |

### How to read those results
- **State-injected:** the certificate test marks Stage 1 courses complete directly in the save (after one
  course and the stage final were completed through the interface) so that a certificate can be generated.
- **Mocked / blocked:** the online code runner is deliberately unreachable in the tests. What is tested is
  that the app reports "not graded" and never awards a pass.
- **Unit-tested in isolation:** the cloud-sync merge function is extracted from `index.html` and run in
  Node; it was not tested against GitHub.

## Not tested (needs services or devices not available to the build)
| Area | Why | How to check it yourself |
|---|---|---|
| Java, Go, Rust, PHP, Ruby, Swift, Kotlin, Bash actually executing | The public runner services could not be reached | Open Labs, pick the language, press Run while online |
| Video playback inside the page | YouTube could not be reached | Open a video page and press Load video. IDs were checked against public listings only |
| Multiplayer, friends, rooms, leaderboards, reward codes | Need the live Firebase project | Play a match after any rules change |
| GitHub cloud sync end to end | Needs a GitHub token | Sync on two browsers and compare the University dashboard |
| Real GitHub Pages and Netlify deployments | Served locally at `/Learn/` and at the root instead | Follow `docs/DEPLOYMENT.md` |
| Real iPad, iPhone and Android browsers | Tested in desktop Chromium at phone, tablet and desktop sizes | Open the site on the device; check the editor and the tab bar |
| Screen readers | Only an automated label check was run on the new pages | Try VoiceOver or TalkBack on a lesson and an examination |
| AI endpoint examples | No provider key | Deploy one and follow its README |
| Firebase rules draft | Cannot be applied to a live database from here | Apply in a test project first |
