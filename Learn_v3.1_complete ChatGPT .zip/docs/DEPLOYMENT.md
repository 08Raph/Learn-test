# Deploying Learn 3.1

The site is static files. There is no build step and nothing to install.

## Upload
Upload **everything in this folder**, keeping the folder structure: `index.html`, `sw.js`, `manifest.json`,
the icons, `ranked_questions.json`, `workspace.js`, `.nojekyll`, and the folders `uni/`, `docs/` and
`tests/` (the last two are optional on the live site).

- **GitHub Pages (project site, served under `/Learn/`):** Add file > Upload files, drag everything in,
  commit to `main`. Settings > Pages > Deploy from a branch > `main` / root. All paths are relative.
- **Netlify:** drag the folder onto the Netlify dashboard, or connect the repository with no build command
  and the publish directory set to the repository root.
- **Local:** `python3 -m http.server 8000` in this folder, then open `http://localhost:8000/`.

## After uploading
1. Open the site and reload once. The service worker (`learn-v3.3`) replaces the old cache; returning
   visitors get the new version on their second visit.
2. Open the patch notes from the home page and confirm version 3.1.
3. Open 🎓 University > Departments.

Existing users keep their progress. The save format only gained optional fields.

## When you change content later
- Change University content or code: bump `UNI_VER` in `index.html` **and** the cache name `VER` in `sw.js`.
- Change the main app: bump `APP_VERSION`, add a `PATCH_NOTES` entry at the top, bump `VER` in `sw.js`.
- Run the tests (see `docs/TESTING.md`).

## Manual actions this release asks of you
| Action | Why | Where |
|---|---|---|
| Tighten the Firebase Realtime Database rules | The database is world-readable and world-writable | `docs/SECURITY.md` finding A, `docs/firebase-rules.draft.json` (untested draft) |
| Use a long random admin passphrase, and treat reward codes as untrusted until rules are fixed | Admin mode is not a real boundary | `docs/SECURITY.md` finding B |
| (Optional) connect an AI model | Needs your own server endpoint and key | `uni/ai-endpoint-example/README.md` |

Nothing in this release requires a paid service.
