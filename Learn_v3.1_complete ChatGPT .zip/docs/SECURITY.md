# Learn 3.1: security review

Reviewed: the whole client application (`index.html`, `sw.js`, `uni/`), its use of the Firebase Realtime
Database, the GitHub cloud-sync feature, the online code runners and the optional AI endpoint examples.

**Nothing in this release changed any live service.** No database rules were changed, no data was deleted,
no credentials were created. Items marked MANUAL need you to act.

## Fixed in this release

| # | Finding | Severity | Fix |
|---|---|---|---|
| 1 | `esc()` (the app-wide HTML escaper) did not escape `"` or `'`. Text placed in attribute values, such as the transcript name field, could break out of the attribute and add an event handler. A hostile backup code or synced save could have used this. | High | `esc()` now escapes both quote characters everywhere. Tested with attribute-injection payloads in the name field and CV builder. |
| 2 | University progress was missing from GitHub cloud sync, so a device restored from sync silently lost it. | Medium (data loss) | Included in the snapshot; merged as a union so no completed item or exam attempt is lost. Unit tested. |
| 3 | An examination result gave no explanation of marking, and did not say when a programming question could not be graded. | Low (integrity) | Results now state how each kind of question was marked and list ungraded questions explicitly. Ungraded work never counts as correct. |

## Open findings that need your action

### A. The multiplayer database is open to everyone (High) — MANUAL
The setup instructions in the app publish these Realtime Database rules:

```json
{"rules":{"duel":{".read":true,".write":true}}}
```

and the app talks to the database with unauthenticated REST calls. Consequences, for anyone who knows the
database URL (it is in the page source):

- They can **read everything** under `/duel`: names, friend lists, inboxes, presence, room contents.
- They can **write anything**: forge leaderboard entries, impersonate players, delete rooms or all data, and
  create or redeem reward codes.

This cannot be fixed in the browser. Options, in order of effort:

1. **Minimum, today:** apply `docs/firebase-rules.draft.json`. It keeps the app working with the same
   paths but refuses reads of the whole tree and writes outside the known top-level paths. It does **not**
   stop a determined person. It was written from the paths used in the code and **has not been tested
   against your live database**. Apply it in a copy of the project first, play a match, then publish.
2. **Proper fix:** turn on Firebase Authentication (anonymous sign-in is free), send the ID token with every
   request, and write rules that tie each path to `auth.uid` (a player may write only their own profile,
   inbox messages only as themselves, and so on). This needs changes to the multiplayer code and testing
   with real accounts. It was not attempted here because it cannot be verified without your project.
3. Keep regular exports of the database so that vandalism can be undone.

### B. Admin mode is not a security boundary (High) — MANUAL
`ADMIN_HASH` is an unsalted SHA-256 of the admin passphrase, shipped in the page. Two problems:

- Anyone can download the page and guess passphrases offline at billions per second. A short or common
  passphrase will be found.
- More fundamentally, the admin panel only writes to `/duel/codes`, and finding A means **anyone can write
  there without the passphrase**.

Treat reward codes as untrusted until A is fixed with authenticated rules that restrict `/duel/codes` to an
administrator account. Use a long random passphrase meanwhile, and do not reuse it anywhere.

### C. GitHub cloud sync stores a personal access token in the browser (Medium)
The token the user pastes is kept in `localStorage` so sync can run. Any script that ran on the page could
read it. Advice to give users: create a **fine-grained token limited to Gists only**, and revoke it if a
device is lost. Finding 1 (now fixed) was the kind of flaw that could have exposed it.

### D. Progress, grades and certificates can be edited by the student (by design)
All progress is in the browser. A student can edit it with developer tools. The app says so on the
transcript and on every certificate. **Do not use these records for any official purpose.** Verifiable
credentials would need a server that marks work itself.

### E. Third-party code runners receive the student's code (Low)
Java, Go, Rust, PHP, Ruby, Swift, Kotlin and Bash are sent to public services (Judge0 CE, Piston, Wandbox).
The app tells the user this. Code may be logged by those services. Nothing else is sent (no name, no
progress).

## Reviewed and found acceptable

- **Code execution:** browser-run languages use interpreters written for this app; JavaScript runs through
  `new Function` in the page with a loop limit. A student can only attack their own session. HTML previews
  use a sandboxed iframe with no script permission.
- **University content:** course text is escaped before markdown is applied; links must be `https://`.
- **User input in the University:** names, CV fields, project notes and links are escaped on output; links
  are validated; the saved state is sanitised on load because a restored backup is untrusted input.
- **Service worker:** caches same-origin GET requests only; never caches database or API traffic.
- **AI Professor:** no key, no provider URL and no network call ship with the site. The endpoint examples
  keep the key in server environment variables, check the origin, cap sizes and rate-limit.
- **No secrets found** in the repository by a scan for key patterns.

## Not possible on static hosting

A Content-Security-Policy that forbids inline script and `eval` would be the strongest defence against
injection, but the app is one inline script and its JavaScript lessons need `eval`. Splitting the app into
files would allow a useful policy; that is a large refactor and was not done.
