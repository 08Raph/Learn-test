# Learn 3.1: what data the site handles

Written for the site owner. Adapt it into a notice for your users.

## Stored only on the user's device (browser `localStorage`)
- Lesson progress, XP, shop items, avatar, settings.
- University record: lessons, assignment code, examination attempts and scores, project notes and links,
  bookmarks, weekly goal, weekly challenge results, interview practice results.
- The name typed for the transcript and certificates.
- CV builder fields, including an email address if the user types one. It appears only in the file they
  export. It is never transmitted by the site.
- A GitHub token, only if the user sets up cloud sync.

Clearing the browser's site data deletes all of it. The backup code contains the same data; whoever holds a
backup code holds that data.

## Sent to other services
| When | What is sent | To whom |
|---|---|---|
| Online play, friends, rooms, leaderboards, reward codes | Display name, avatar, scores, messages, presence | Your Firebase Realtime Database. With the current rules this data is readable by anyone (see SECURITY.md, finding A). |
| Cloud sync, if the user sets it up | Their whole save, as a private Gist | GitHub, in the user's own account |
| Running Java, Go, Rust, PHP, Ruby, Swift, Kotlin or Bash | The code being run | Judge0 CE, Piston or Wandbox (public services) |
| Pressing "Load video" | A request to the video host, which may set cookies | YouTube (privacy-enhanced embed domain) |
| Web fonts | A request for the font files | Google Fonts |
| AI Professor | **Nothing.** No AI service is connected. If you connect one, messages typed on that page go to your endpoint and on to the provider. | — |

The University's departments, career centre, CV builder, study tools and challenges send **nothing** anywhere.
There are no analytics, advertising or tracking scripts.

## Younger users
The site asks for no age, real name or contact details. If children use it: online play shares a display
name with other players, so advise them not to use a real name; and the career guide tells under-18s to
involve a parent, guardian or teacher.

## Your obligations
If you operate this for other people, you are responsible for the Firebase project. Depending on where you
and your users are, data-protection law may apply to the names and messages stored there. This is general
information, not legal advice.
