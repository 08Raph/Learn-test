#!/bin/sh
# Runs the whole test programme against this folder. Needs: node + playwright (chromium), python3.
# Usage: sh tests/run-all.sh        (from the site folder)
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT" || exit 1
TMP="$(mktemp -d)"; ln -s "$ROOT" "$TMP/Learn"
python3 -m http.server 8765 --directory "$ROOT" >/dev/null 2>&1 & SRV=$!
sleep 1
echo "== content validator (every solution and starter through the real grader)"; node tests/validate-content.js; A=$?
kill $SRV 2>/dev/null
echo "== end-to-end: core University"; SRV_DIR="$TMP" APP_DIR="$ROOT" node tests/e2e-core.js | tail -3
echo "== end-to-end: departments, career, study, finals, certificates"; SRV_DIR="$TMP" APP_DIR="$ROOT" node tests/e2e-campus.js | tail -3
rm -rf "$TMP"
echo "Done. A line ending '0 problems' and two lines starting '0 failed' mean everything passed."
