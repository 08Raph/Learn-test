/* Technology University: departments, elective courses and career-centre data (metadata only).
   - Departments are views over the course catalogue. They never change the six-stage programme.
   - Elective courses live in UNI_CATALOG.electives. They are real courses (lessons, assignment, exam, project)
     but do NOT count toward stage completion, graduation or the 52-course / 255-lesson totals.
   - Add a department: add an entry to `depts`. Add an elective: add an entry to `electives` and a #COURSE block
     in data/electives.txt, then run the content validator (tests/validate-content.js). */
(function () {
  const CAT = window.UNI_CATALOG; if (!CAT) return;
  const El = (id, code, dept, title, desc, obj, o) => Object.assign({ id, code, dept, title, desc, obj, elective: true, stage: 1, sub: 'Elective', n: 4, hrs: 6, pre: [], lab: true, lang: 'js', project: true, file: 'electives.txt', skills: [], topics: [], refs: [] }, o || {});
  CAT.electives = [
    El('gd101', 'GDV 101', 'game', 'Game Programming Foundations', 'How real-time games work underneath: the game loop, time steps, vectors, collision detection and entity design. You build the logic of a small 2D game engine and test it.',
      ['Explain the game loop and why a fixed time step matters', 'Use 2D vectors for movement and distance', 'Detect and resolve collisions between boxes and circles', 'Structure game objects with components'],
      { pre: ['c105'], skills: ['Game loop design', '2D vector maths', 'Collision detection'], topics: ['game', 'game loop', 'collision', 'vector'], ptitle: 'A complete small 2D game',
        refs: [['Game Programming Patterns (Nystrom)', 'https://gameprogrammingpatterns.com/', 'Free book'], ['Fix Your Timestep! (Fiedler)', 'https://gafferongames.com/post/fix_your_timestep/', 'The classic article on game time steps'], ['MDN: 2D breakout game tutorial', 'https://developer.mozilla.org/en-US/docs/Games/Tutorials/2D_Breakout_game_pure_JavaScript', 'Build a first canvas game']] }),
    El('ce101', 'CEN 101', 'ce', 'Digital Logic and How a CPU Executes', 'From transistors to a running program: logic gates, adders, memory elements, and a tiny processor whose fetch-decode-execute cycle you simulate yourself.',
      ['Build any Boolean function from basic gates', 'Explain how an adder adds binary numbers', 'Describe registers, memory and the fetch-decode-execute cycle', 'Trace a small machine-code program by hand'],
      { pre: ['c101'], skills: ['Digital logic', 'Binary arithmetic circuits', 'CPU fundamentals'], topics: ['logic gate', 'adder', 'cpu', 'machine code', 'computer engineering'], ptitle: 'An 8-bit computer simulator',
        refs: [['From Nand to Tetris', 'https://www.nand2tetris.org/', 'Free course: build a computer from gates'], ['Code: The Hidden Language of Computer Hardware and Software (Petzold)', '', 'A readable book on how computers work'], ['MIT 6.004 Computation Structures', 'https://ocw.mit.edu/courses/6-004-computation-structures-spring-2017/', 'MIT OpenCourseWare']] }),
    El('mb101', 'MOB 101', 'mobile', 'Mobile Application Foundations', 'What makes mobile software different: the app lifecycle, navigation stacks, state management, touch-first layout, and working when the network is unreliable.',
      ['Explain the mobile app lifecycle and why state must be saved', 'Model navigation as a stack', 'Manage state with a reducer', 'Design an offline-first sync queue'],
      { pre: ['c105', 'c106'], skills: ['Mobile app architecture', 'State management', 'Offline-first design'], topics: ['mobile', 'lifecycle', 'navigation', 'offline', 'reducer'], ptitle: 'An offline-first mobile app',
        refs: [['Android Developers: Guide to app architecture', 'https://developer.android.com/topic/architecture', 'Official guide'], ['Apple: Human Interface Guidelines', 'https://developer.apple.com/design/human-interface-guidelines/', 'Official design guidance'], ['web.dev: Progressive Web Apps', 'https://web.dev/explore/progressive-web-apps', 'Installable web apps']] }),
  ];

  const depts = [
    { id: 'se', icon: '🛠', name: 'Software Engineering', blurb: 'The complete six-stage programme: designing, building, testing and running software professionally.',
      outcomes: ['Design and build maintainable software', 'Test, review and deliver it with automation', 'Architect systems and lead technical work'],
      path: ['c103', 'c104', 'c201', 'c207', 'c206', 'c302', 'c303', 'c308', 'c309', 'c403', 'c409', 'c601', 'c603', 'c604', 'c606'],
      note: 'This is the original University. Every one of its 52 courses is listed in the course catalogue; the pathway below is the spine.', careers: ['backend', 'fullstack', 'frontend'] },
    { id: 'cs', icon: '🧮', name: 'Computer Science', blurb: 'The theory under the practice: mathematics, algorithms, computability, languages, architecture and research.',
      outcomes: ['Prove properties of algorithms and programs', 'Analyse complexity and recognise intractable problems', 'Carry out and report independent research'],
      path: ['c101', 'c102', 'c202', 'c203', 'c301', 'c307', 'c406', 'c501', 'c502', 'c503', 'c504', 'c505', 'c506', 'c508', 'c510', 'c608'],
      note: 'Not yet covered in depth here: computer graphics, human-computer interaction and numerical methods. The references on each course page point to full university courses for those.', careers: ['backend', 'ml'] },
    { id: 'ai', icon: '🧠', name: 'Artificial Intelligence and Machine Learning', blurb: 'The mathematics of learning from data, neural networks, language models, and operating them responsibly.',
      outcomes: ['Derive and implement gradient descent and backpropagation', 'Evaluate models honestly and detect drift', 'Build and govern applications on language models'],
      path: ['c103', 'c203', 'c502', 'c507', 'c605', 'c510', 'c608'],
      note: 'Two dedicated courses (SEU 507 and SEU 605) plus the mathematics and research courses they rely on. Specialist topics such as computer vision, reinforcement learning in depth and natural-language processing are introduced, not taught in full.', careers: ['ml'] },
    { id: 'sec', icon: '🛡', name: 'Cybersecurity', blurb: 'Threat modelling, cryptography, secure design, privacy engineering and security at organisational scale.',
      outcomes: ['Model threats and find vulnerabilities in a design', 'Apply cryptography and identity correctly', 'Engineer privacy and plan detection and response'],
      path: ['c304', 'c306', 'c307', 'c407', 'c509', 'c602'],
      note: 'All practical work must be done on systems you own or are explicitly authorised to test. Offensive specialisms (exploit development, malware analysis) are described for defenders, not taught as skills.', careers: ['security'] },
    { id: 'game', icon: '🎮', name: 'Game Development', blurb: 'Real-time simulation: game loops, vectors, collisions and performance, built on solid programming foundations.',
      outcomes: ['Write a correct fixed-time-step game loop', 'Implement movement and collision with vector maths', 'Reason about performance and memory in real-time code'],
      path: ['c105', 'gd101', 'c201', 'c202', 'c203', 'c204', 'c404', 'c502', 'c505'],
      note: 'One dedicated course (GDV 101) so far. The pathway adds the programming, mathematics and performance courses that game programming depends on. Not covered yet: 3D graphics, shaders, commercial engines, audio and game design.', careers: ['game'] },
    { id: 'ce', icon: '🔌', name: 'Computer Engineering', blurb: 'Where software meets hardware: digital logic, processors, memory, operating systems and low-level languages.',
      outcomes: ['Explain how logic gates become a working processor', 'Write and reason about low-level code in C', 'Relate program performance to caches, pipelines and memory'],
      path: ['c101', 'ce101', 'c204', 'c307', 'c306', 'c404', 'c405', 'c406', 'c505'],
      note: 'One dedicated course (CEN 101) so far, plus the systems courses of the main programme. Not covered yet: electronics, hardware description languages, embedded microcontrollers and signal processing. Those need physical or specialised tools this site cannot provide.', careers: ['embedded'] },
    { id: 'cloud', icon: '☁️', name: 'Cloud Computing and DevOps', blurb: 'Delivering and running software: version control, pipelines, containers, Kubernetes, reliability and scale.',
      outcomes: ['Automate build, test and deployment', 'Run workloads reliably on a container platform', 'Define SLOs and manage incidents and capacity'],
      path: ['c107', 'c206', 'c306', 'c308', 'c401', 'c402', 'c408', 'c602', 'c607'],
      extra: [['#/cloud', 'Deploying to the Cloud', 'The hands-on deployment simulator track in the main Learn app']],
      note: 'The labs here simulate cloud systems in the browser. Nothing on this site creates real cloud resources or costs money.', careers: ['devops'] },
    { id: 'mobile', icon: '📱', name: 'Mobile Application Development', blurb: 'Apps for phones and tablets: lifecycle, navigation, state, touch-first design and offline-first data.',
      outcomes: ['Structure an app around lifecycle and navigation', 'Manage state predictably', 'Keep an app usable offline and sync safely'],
      path: ['c105', 'c106', 'mb101', 'c201', 'c303', 'c304', 'c305'],
      labs: ['swift', 'kotlin'],
      note: 'One dedicated course (MOB 101) so far. Swift and Kotlin practice labs are available but run on an online service. Not covered yet: native UI toolkits (SwiftUI, Jetpack Compose), app-store release and device APIs. Building native apps needs the platform tools on your own computer.', careers: ['mobile'] },
  ];

  /* ---------- career centre ---------- */
  const roles = [
    { id: 'frontend', name: 'Front-end developer', does: 'Builds what users see and touch in the browser: layout, interaction, accessibility and performance.', need: ['c103', 'c105', 'c106', 'c206', 'c207', 'c303', 'c304'], next: ['c302', 'c308'] },
    { id: 'backend', name: 'Back-end developer', does: 'Builds the services and data behind an application: APIs, databases, security and reliability.', need: ['c103', 'c104', 'c201', 'c202', 'c203', 'c205', 'c207', 'c303', 'c304', 'c305', 'c308'], next: ['c306', 'c307', 'c401'] },
    { id: 'fullstack', name: 'Full-stack developer', does: 'Works across the browser, the server and the database, and ships complete features.', need: ['c103', 'c105', 'c106', 'c201', 'c205', 'c206', 'c207', 'c303', 'c304', 'c308', 'c309'], next: ['c305', 'c402', 'c606'] },
    { id: 'devops', name: 'DevOps / site reliability engineer', does: 'Automates delivery and keeps systems running: pipelines, containers, monitoring, incidents and capacity.', need: ['c107', 'c206', 'c306', 'c307', 'c308', 'c401', 'c402', 'c408'], next: ['c602', 'c607'] },
    { id: 'security', name: 'Security engineer', does: 'Finds and fixes weaknesses, designs secure systems, and prepares for and responds to attacks.', need: ['c304', 'c306', 'c307', 'c407'], next: ['c509', 'c602'] },
    { id: 'ml', name: 'Machine-learning engineer', does: 'Builds, evaluates, deploys and monitors models and the data pipelines round them.', need: ['c103', 'c203', 'c205', 'c502', 'c507'], next: ['c605', 'c510'] },
    { id: 'mobile', name: 'Mobile developer', does: 'Builds apps for phones and tablets that stay responsive and usable with poor connectivity.', need: ['c103', 'c105', 'c106', 'mb101', 'c201', 'c303', 'c304'], next: ['c305', 'c308'] },
    { id: 'game', name: 'Game programmer', does: 'Writes the real-time code of games: simulation, collision, tools and performance-critical systems.', need: ['c103', 'c105', 'gd101', 'c201', 'c202', 'c203', 'c204'], next: ['c404', 'c502', 'c505'] },
    { id: 'embedded', name: 'Embedded / systems programmer', does: 'Writes software close to the hardware: firmware, drivers, operating-system and performance-sensitive code.', need: ['c101', 'ce101', 'c204', 'c307', 'c306'], next: ['c404', 'c405', 'c505'] },
  ];

  // Interview practice. Concept questions are self-checked against key points (clearly labelled self-assessed).
  const concepts = [
    ['Data structures', 'When would you choose a hash map over a balanced tree, and when the reverse?', ['Hash map: average O(1) lookup by exact key', 'Tree: keeps keys ordered, supports range queries and ordered traversal in O(log n)', 'Mentions worst cases or memory/ordering trade-offs'], 'c202'],
    ['Algorithms', 'Explain Big O notation and give the complexity of binary search and of merge sort, with reasons.', ['Describes growth of running time with input size, ignoring constants', 'Binary search O(log n): halves the search space each step', 'Merge sort O(n log n): log n levels, n work per level'], 'c203'],
    ['Databases', 'What is an index, and what does it cost?', ['A structure (usually a B-tree) that finds rows without scanning the table', 'Speeds up reads that filter or sort on the indexed columns', 'Costs extra storage and slower writes'], 'c205'],
    ['Databases', 'Explain ACID. Which property stops two concurrent transfers corrupting a balance?', ['Atomicity, consistency, isolation, durability, each explained', 'Isolation prevents the interference', 'Mentions isolation levels or locking/MVCC'], 'c305'],
    ['Web', 'What happens when you type a URL into a browser and press Enter?', ['DNS lookup', 'TCP and TLS connection', 'HTTP request and response', 'Browser parses HTML, fetches resources, renders'], 'c306'],
    ['Security', 'What is the difference between authentication and authorisation? Give an example of a bug in each.', ['Authentication: proving who you are', 'Authorisation: what you are allowed to do', 'Example such as weak password storage versus reading another user\'s record'], 'c304'],
    ['Security', 'How should passwords be stored, and why?', ['Never in plain text or reversible encryption', 'A slow, salted password-hashing function such as Argon2, scrypt or bcrypt', 'Salt defeats precomputed tables; slowness defeats guessing'], 'c304'],
    ['Design', 'What does the single responsibility principle mean, and how do you recognise a violation?', ['A module should have one reason to change', 'Violation: a class mixing unrelated concerns such as business rules and database access', 'Mentions the benefit for testing and change'], 'c302'],
    ['Testing', 'What is the difference between unit, integration and end-to-end tests? How many of each?', ['Unit: one piece in isolation, fast', 'Integration: pieces working together, such as code with a real database', 'End-to-end: a whole user journey; fewest because slow and brittle (the test pyramid)'], 'c207'],
    ['Concurrency', 'What is a race condition? How would you find and fix one?', ['Outcome depends on the timing of concurrent operations on shared state', 'Find with stress tests, race detectors, careful review', 'Fix with locks, atomic operations, or by not sharing mutable state'], 'c307'],
    ['Systems', 'Your API is suddenly slow. How do you investigate?', ['Check what changed (deploys, traffic, dependencies)', 'Look at metrics, logs and traces to locate where time goes', 'Form a hypothesis, test it, mitigate first (roll back) then fix the cause'], 'c404'],
    ['Distributed systems', 'Explain the CAP theorem with an example of each choice.', ['During a network partition a system must choose consistency or availability', 'Consistent choice: refuse some requests (for example a bank balance)', 'Available choice: accept and reconcile later (for example a shopping cart)'], 'c401'],
    ['System design', 'How would you scale a read-heavy web service?', ['Measure first; add indexes and caching', 'Stateless application servers behind a load balancer', 'Read replicas and a CDN; mentions cache invalidation or replica lag'], 'c402'],
    ['Machine learning', 'What is overfitting and how do you detect and reduce it?', ['Model fits noise in training data and performs worse on new data', 'Detect: gap between training and validation performance', 'Reduce: more data, simpler model, regularisation, early stopping'], 'c507'],
  ];
  const behavioural = [
    'Tell me about a project you are proud of. What exactly did you build, and what was hard?',
    'Describe a bug that took you a long time to find. How did you find it?',
    'Tell me about a time you disagreed with someone about a technical decision. What happened?',
    'Describe a time you made a mistake. What did you do about it?',
    'Tell me about something you learned recently and how you learned it.',
    'Describe a time you had too much to do. How did you decide what to do first?',
    'Tell me about a time you received critical feedback. How did you respond?',
    'Why do you want this kind of role, and what do you hope to learn in it?',
  ];
  // Programming interview exercises: graded by the same test runner as course assignments.
  const T = (expr, exp, setup) => [expr, exp, setup || ''];
  const coding = [
    { id: 'iv-two-sum', lang: 'js', level: 'Easy', title: 'Two sum', md: 'Write `twoSum(numbers, target)` that returns the **indices** of the two numbers that add up to `target`, as an array `[i, j]` with `i < j`. Exactly one answer exists. Aim for O(n).',
      starter: 'function twoSum(numbers, target) {\n  return [];\n}\n', solution: 'function twoSum(numbers, target) {\n  const seen = new Map();\n  for (let i = 0; i < numbers.length; i++) {\n    const need = target - numbers[i];\n    if (seen.has(need)) return [seen.get(need), i];\n    seen.set(numbers[i], i);\n  }\n  return [];\n}\n',
      tests: [T('twoSum([2, 7, 11, 15], 9)', [0, 1]), T('twoSum([3, 2, 4], 6)', [1, 2]), T('twoSum([3, 3], 6)', [0, 1]), T('twoSum([-1, 5, 9, 1], 0)', [0, 3])], hints: ['As you scan, ask whether you have already seen the number that would complete the current one.', 'A Map from value to index answers that in constant time.'] },
    { id: 'iv-valid-brackets', lang: 'js', level: 'Easy', title: 'Valid brackets', md: 'Write `isValid(text)` that returns true if every `(`, `[` and `{` is closed by the right bracket in the right order. The input contains only bracket characters.',
      starter: 'function isValid(text) {\n  return false;\n}\n', solution: 'function isValid(text) {\n  const pairs = { ")": "(", "]": "[", "}": "{" };\n  const stack = [];\n  for (const c of text) {\n    if (pairs[c]) { if (stack.pop() !== pairs[c]) return false; }\n    else stack.push(c);\n  }\n  return stack.length === 0;\n}\n',
      tests: [T('isValid("()[]{}")', true), T('isValid("(]")', false), T('isValid("([{}])")', true), T('isValid("((")', false), T('isValid("")', true), T('isValid(")(")', false)], hints: ['Use a stack: push openers, and on a closer check the top of the stack.'] },
    { id: 'iv-reverse-words', lang: 'py', level: 'Easy', title: 'Reverse the words', md: 'Write `reverse_words(text)` that returns the words of `text` in reverse order, separated by single spaces. Extra spaces in the input are ignored.',
      starter: 'def reverse_words(text):\n    return text\n', solution: 'def reverse_words(text):\n    words = text.split()\n    out = []\n    i = len(words) - 1\n    while i >= 0:\n        out.append(words[i])\n        i = i - 1\n    return " ".join(out)\n',
      tests: [T('reverse_words("the sky is blue")', 'blue is sky the'), T('reverse_words("  hello   world ")', 'world hello'), T('reverse_words("one")', 'one'), T('reverse_words("")', '')], hints: ['`text.split()` with no argument splits on any run of spaces.'] },
    { id: 'iv-merge-intervals', lang: 'js', level: 'Medium', title: 'Merge intervals', md: 'Write `merge(intervals)` where each interval is `[start, end]`. Return the intervals with every overlapping pair merged, sorted by start. Intervals that touch (`[1, 2]` and `[2, 3]`) count as overlapping.',
      starter: 'function merge(intervals) {\n  return intervals;\n}\n', solution: 'function merge(intervals) {\n  const sorted = intervals.slice().sort((a, b) => a[0] - b[0]);\n  const out = [];\n  for (const cur of sorted) {\n    const last = out[out.length - 1];\n    if (last && cur[0] <= last[1]) last[1] = Math.max(last[1], cur[1]);\n    else out.push([cur[0], cur[1]]);\n  }\n  return out;\n}\n',
      tests: [T('merge([[1, 3], [2, 6], [8, 10], [15, 18]])', [[1, 6], [8, 10], [15, 18]]), T('merge([[1, 4], [4, 5]])', [[1, 5]]), T('merge([[5, 7], [1, 2]])', [[1, 2], [5, 7]]), T('merge([])', []), T('merge([[1, 10], [2, 3], [4, 5]])', [[1, 10]])], hints: ['Sort by start first.', 'Then each interval either extends the last merged one or starts a new one.'] },
    { id: 'iv-anagram-groups', lang: 'py', level: 'Medium', title: 'Group anagrams', md: 'Write `group_anagrams(words)` that returns a list of groups, where each group is a list of words that are anagrams of each other. Keep words in their original order inside each group, and order the groups by the first appearance of any of their words.',
      starter: 'def group_anagrams(words):\n    return []\n', solution: 'def group_anagrams(words):\n    order = []\n    groups = {}\n    for w in words:\n        key = "".join(sorted(w))\n        if key not in groups:\n            groups[key] = []\n            order.append(key)\n        groups[key].append(w)\n    out = []\n    for k in order:\n        out.append(groups[k])\n    return out\n',
      tests: [T('group_anagrams(["eat", "tea", "tan", "ate", "nat", "bat"])', [['eat', 'tea', 'ate'], ['tan', 'nat'], ['bat']]), T('group_anagrams([])', []), T('group_anagrams(["a"])', [['a']])], hints: ['Two words are anagrams exactly when their sorted letters are equal. Use that as a dictionary key.'] },
    { id: 'iv-lru', lang: 'js', level: 'Hard', title: 'Design an LRU cache', md: 'Implement `class LRU` created with `new LRU(capacity)`. `get(key)` returns the value or `-1` and marks the key as most recently used. `put(key, value)` stores it and, if over capacity, evicts the least recently used key. Both must be O(1).',
      starter: 'class LRU {\n  constructor(capacity) {\n    this.capacity = capacity;\n  }\n  get(key) {\n    return -1;\n  }\n  put(key, value) {\n  }\n}\n', solution: 'class LRU {\n  constructor(capacity) {\n    this.capacity = capacity;\n    this.map = new Map();\n  }\n  get(key) {\n    if (!this.map.has(key)) return -1;\n    const v = this.map.get(key);\n    this.map.delete(key);\n    this.map.set(key, v);\n    return v;\n  }\n  put(key, value) {\n    if (this.map.has(key)) this.map.delete(key);\n    this.map.set(key, value);\n    if (this.map.size > this.capacity) this.map.delete(this.map.keys().next().value);\n  }\n}\n',
      tests: [T('(() => { const c = new LRU(2); c.put(1, 1); c.put(2, 2); const a = c.get(1); c.put(3, 3); return [a, c.get(2), c.get(3)]; })()', [1, -1, 3]), T('(() => { const c = new LRU(1); c.put(1, 1); c.put(2, 2); return [c.get(1), c.get(2)]; })()', [-1, 2]), T('(() => { const c = new LRU(2); c.put(1, 1); c.put(1, 9); c.put(2, 2); c.put(3, 3); return [c.get(1), c.get(2), c.get(3)]; })()', [-1, 2, 3])], hints: ['A JavaScript Map remembers insertion order.', 'Delete and re-insert a key to move it to the most-recent end; the first key is the least recent.'] },
  ];

  window.UNI_DEPTS = { depts, roles, concepts, behavioural, coding };
})();
